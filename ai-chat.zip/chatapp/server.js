import express from "express";
import multer from "multer";
import cors from "cors";
import fs from "fs";
import path from "path";
import fetch from "node-fetch";
import FormData from "form-data";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = process.env.PORT || 3000;

const ANTHROPIC_API_KEY = process.env.ANTHROPIC_API_KEY || "";
const OPENAI_API_KEY = process.env.OPENAI_API_KEY || "";

app.use(cors());
app.use(express.json({ limit: "50mb" }));
app.use(express.static(path.join(__dirname, "public")));

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 20 * 1024 * 1024 },
});

// Chat endpoint
app.post("/api/chat", upload.array("files"), async (req, res) => {
  try {
    const { message, model, history } = req.body;
    const files = req.files || [];
    const parsedHistory = history ? JSON.parse(history) : [];

    if (model === "claude") {
      const result = await callClaude(message, files, parsedHistory);
      res.json({ reply: result });
    } else if (model === "gpt") {
      const result = await callGPT(message, files, parsedHistory);
      res.json({ reply: result });
    } else {
      res.status(400).json({ error: "Noma'lum model" });
    }
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message || "Server xatosi" });
  }
});

async function callClaude(message, files, history) {
  const messages = [];

  for (const h of history) {
    messages.push({ role: h.role, content: h.content });
  }

  const userContent = [];

  for (const file of files) {
    const mime = file.mimetype;
    const base64 = file.buffer.toString("base64");

    if (mime.startsWith("image/")) {
      userContent.push({
        type: "image",
        source: { type: "base64", media_type: mime, data: base64 },
      });
    } else if (mime === "application/pdf") {
      userContent.push({
        type: "document",
        source: { type: "base64", media_type: "application/pdf", data: base64 },
      });
    } else {
      const text = file.buffer.toString("utf-8");
      userContent.push({
        type: "text",
        text: `[Fayl: ${file.originalname}]\n${text}`,
      });
    }
  }

  if (message) {
    userContent.push({ type: "text", text: message });
  }

  messages.push({ role: "user", content: userContent });

  const response = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": ANTHROPIC_API_KEY,
      "anthropic-version": "2023-06-01",
    },
    body: JSON.stringify({
      model: "claude-sonnet-4-5",
      max_tokens: 4096,
      messages,
    }),
  });

  const data = await response.json();
  if (!response.ok) throw new Error(data.error?.message || "Claude API xatosi");
  return data.content[0]?.text || "";
}

async function callGPT(message, files, history) {
  const messages = [];

  for (const h of history) {
    messages.push({ role: h.role, content: h.content });
  }

  const userContent = [];

  for (const file of files) {
    const mime = file.mimetype;
    const base64 = file.buffer.toString("base64");

    if (mime.startsWith("image/")) {
      userContent.push({
        type: "image_url",
        image_url: { url: `data:${mime};base64,${base64}` },
      });
    } else {
      const text = file.buffer.toString("utf-8");
      userContent.push({
        type: "text",
        text: `[Fayl: ${file.originalname}]\n${text}`,
      });
    }
  }

  if (message) {
    userContent.push({ type: "text", text: message });
  }

  messages.push({ role: "user", content: userContent });

  const response = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${OPENAI_API_KEY}`,
    },
    body: JSON.stringify({
      model: "gpt-4.5-preview",
      messages,
      max_tokens: 4096,
    }),
  });

  const data = await response.json();
  if (!response.ok) throw new Error(data.error?.message || "GPT API xatosi");
  return data.choices[0]?.message?.content || "";
}

app.listen(PORT, () => {
  console.log(`Server http://localhost:${PORT} da ishlamoqda`);
});
